import { GoogleGenAI } from "@google/genai";
import { VisualStyle, EditingStyle, ScriptData, VideoDuration, Complexity } from "../types";

// Helper to ensure we get a fresh instance with the latest selected key
const getAIInstance = (): GoogleGenAI => {
  return new GoogleGenAI({ apiKey: process.env.API_KEY });
};

export const checkApiKey = async (): Promise<boolean> => {
  const win = window as any;
  if (win.aistudio && win.aistudio.hasSelectedApiKey) {
    return await win.aistudio.hasSelectedApiKey();
  }
  return false;
};

export const promptForKeySelection = async (): Promise<void> => {
  const win = window as any;
  if (win.aistudio && win.aistudio.openSelectKey) {
    await win.aistudio.openSelectKey();
  }
};

const fileToBase64 = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => {
      const result = reader.result as string;
      // Remove data url prefix (e.g. "data:image/png;base64,")
      const base64 = result.split(',')[1];
      resolve(base64);
    };
    reader.onerror = error => reject(error);
  });
};

export const generateVideoContent = async (
  scriptData: ScriptData,
  config: {
    visualStyle: VisualStyle;
    editingStyle: EditingStyle;
    duration: VideoDuration;
    complexity: Complexity;
    referenceImage: File | null;
  }
): Promise<string> => {
  const ai = getAIInstance();
  
  // Construct the Scene breakdown string
  const scenesDescription = scriptData.scenes.map((scene, index) => {
    return `Scene ${index + 1}:
    - Location: ${scene.location}
    - Time: ${scene.time}
    - Atmosphere: ${scene.atmosphere}
    - Characters: ${scene.characters}
    - Action: ${scene.action}
    - Key Dialogue: "${scene.dialogue}"`;
  }).join('\n\n');

  // Combine into a comprehensive prompt
  // Note: Veo generates short clips, so we frame this as generating a "Key Sequence" from the larger story.
  const fullPrompt = `
    Create a high-quality video sequence representing a story with a target duration of ${config.duration}.
    Complexity Level: ${config.complexity}.
    
    VISUAL STYLE: ${config.visualStyle}
    EDITING STYLE: ${config.editingStyle}
    
    MAIN PLOT: ${scriptData.plot}
    
    SCENE DETAILS TO VISUALIZE:
    ${scenesDescription}
    
    Ensure smooth motion, consistent lighting, and adherence to the visual style.
  `.trim();

  try {
    const model = 'veo-3.1-fast-generate-preview';
    
    const requestConfig: any = {
      numberOfVideos: 1,
      resolution: '720p',
      aspectRatio: '16:9'
    };

    let imagePart = undefined;
    if (config.referenceImage) {
      const base64Data = await fileToBase64(config.referenceImage);
      imagePart = {
        imageBytes: base64Data,
        mimeType: config.referenceImage.type,
      };
    }

    let operation;
    
    if (imagePart) {
        // If we have an image, we use it as a starting frame/reference
        operation = await ai.models.generateVideos({
            model: model,
            prompt: fullPrompt,
            image: imagePart,
            config: requestConfig
        });
    } else {
        operation = await ai.models.generateVideos({
            model: model,
            prompt: fullPrompt,
            config: requestConfig
        });
    }

    // Poll for completion
    while (!operation.done) {
      // Veo generation takes time, wait 5 seconds between checks
      await new Promise(resolve => setTimeout(resolve, 5000));
      operation = await ai.operations.getVideosOperation({ operation: operation });
      console.log("Processing video...");
    }

    const videoUri = operation.response?.generatedVideos?.[0]?.video?.uri;

    if (!videoUri) {
      throw new Error("No video URI returned from the API.");
    }

    // Append API key to the URI as required by the documentation
    return `${videoUri}&key=${process.env.API_KEY}`;

  } catch (error: any) {
    console.error("Video generation failed:", error);
    // Handle the specific "Requested entity was not found" error which implies key issues
    if (error.message && error.message.includes("Requested entity was not found")) {
      await promptForKeySelection();
      throw new Error("API Key invalid or expired. Please re-select your key.");
    }
    throw error;
  }
};