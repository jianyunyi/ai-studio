export enum VisualStyle {
  CINEMATIC = 'Cinematic, 8k, highly detailed, realistic lighting, movie quality',
  CYBERPUNK = 'Cyberpunk, neon lights, futuristic city, high tech, dark atmosphere, purple and blue tones',
  ANIME = 'Anime style, Studio Ghibli inspired, vibrant colors, detailed backgrounds',
  CLAYMATION = 'Claymation, stop motion animation style, plasticine texture, playful',
  VINTAGE = 'Vintage 1950s film look, grainy, black and white, noir atmosphere',
  SURREAL = 'Surrealist art, dreamlike, Dali-inspired, melting shapes, abstract'
}

export enum EditingStyle {
  FAST_PACED = 'Fast-paced cuts, dynamic transitions, high energy',
  SLOW_CINEMATIC = 'Slow burn, lingering shots, emotional depth, steady cam',
  DOCUMENTARY = 'Handheld camera, realistic angles, observant style',
  MUSIC_VIDEO = 'Rhythmic editing, stylized motion, artistic angles'
}

export enum VideoDuration {
  ONE_MIN = '1 Minute',
  THREE_MIN = '3 Minutes',
  FIVE_MIN = '5 Minutes'
}

export enum Complexity {
  SIMPLE = 'Simple',
  MEDIUM = 'Medium',
  COMPLEX = 'Complex'
}

export interface StyleOption {
  id: string;
  name: string;
  value: VisualStyle | EditingStyle;
  previewColor: string;
  icon: string;
}

export interface Scene {
  id: string;
  location: string;
  time: string;
  atmosphere: string;
  characters: string;
  action: string;
  dialogue: string;
}

export interface ScriptData {
  plot: string;
  scenes: Scene[];
}

export interface VideoGenerationResult {
  videoUri: string;
  prompt: string;
  style: string;
}