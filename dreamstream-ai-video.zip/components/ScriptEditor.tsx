import React from 'react';
import { Plus, Trash2, MapPin, Clock, Smile, MessageSquare, Activity, Cloud } from 'lucide-react';
import { ScriptData, Scene } from '../types';

interface ScriptEditorProps {
  data: ScriptData;
  onChange: (data: ScriptData) => void;
  disabled?: boolean;
}

const ScriptEditor: React.FC<ScriptEditorProps> = ({ data, onChange, disabled }) => {
  
  const handlePlotChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    onChange({ ...data, plot: e.target.value });
  };

  const addScene = () => {
    const newScene: Scene = {
      id: Date.now().toString(),
      location: '',
      time: '',
      atmosphere: '',
      characters: '',
      action: '',
      dialogue: ''
    };
    onChange({ ...data, scenes: [...data.scenes, newScene] });
  };

  const removeScene = (id: string) => {
    onChange({ ...data, scenes: data.scenes.filter(s => s.id !== id) });
  };

  const updateScene = (id: string, field: keyof Scene, value: string) => {
    const updatedScenes = data.scenes.map(s => 
      s.id === id ? { ...s, [field]: value } : s
    );
    onChange({ ...data, scenes: updatedScenes });
  };

  return (
    <div className="space-y-6">
      {/* Main Plot Section */}
      <div className="space-y-2">
        <label className="text-sm font-medium text-purple-200 flex items-center justify-between">
          <span>Main Story Plot</span>
          <span className="text-xs text-slate-500">Core Narrative</span>
        </label>
        <textarea
          className="w-full h-32 bg-slate-900/50 border border-slate-700 rounded-xl p-4 text-slate-100 placeholder:text-slate-600 focus:ring-2 focus:ring-purple-500 focus:border-transparent outline-none resize-none transition-all"
          placeholder="Describe the overall story arc. E.g., A robot discovers emotions in a post-apocalyptic world and tries to save a flower."
          value={data.plot}
          onChange={handlePlotChange}
          disabled={disabled}
        />
      </div>

      {/* Scenes Section */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <label className="text-sm font-medium text-purple-200">Scene Breakdown</label>
          <button
            onClick={addScene}
            disabled={disabled}
            className="text-xs flex items-center gap-1 bg-slate-800 hover:bg-slate-700 text-purple-400 px-3 py-1.5 rounded-full transition-colors"
          >
            <Plus className="w-3 h-3" /> Add Scene
          </button>
        </div>

        <div className="space-y-4">
          {data.scenes.map((scene, index) => (
            <div key={scene.id} className="bg-slate-900/80 border border-slate-800 rounded-xl p-4 relative group">
              <div className="flex items-center justify-between mb-4">
                <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Scene {index + 1}</span>
                {data.scenes.length > 1 && (
                  <button 
                    onClick={() => removeScene(scene.id)}
                    disabled={disabled}
                    className="text-slate-600 hover:text-red-400 transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                )}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Location */}
                <div className="space-y-1">
                  <div className="flex items-center gap-2 text-xs text-slate-400">
                    <MapPin className="w-3 h-3" /> Location
                  </div>
                  <input 
                    type="text" 
                    value={scene.location}
                    onChange={(e) => updateScene(scene.id, 'location', e.target.value)}
                    disabled={disabled}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-sm text-slate-200 focus:border-purple-500 outline-none"
                    placeholder="e.g. Abandoned Factory"
                  />
                </div>

                {/* Time */}
                <div className="space-y-1">
                  <div className="flex items-center gap-2 text-xs text-slate-400">
                    <Clock className="w-3 h-3" /> Time
                  </div>
                  <input 
                    type="text" 
                    value={scene.time}
                    onChange={(e) => updateScene(scene.id, 'time', e.target.value)}
                    disabled={disabled}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-sm text-slate-200 focus:border-purple-500 outline-none"
                    placeholder="e.g. Midnight, rainy"
                  />
                </div>

                {/* Atmosphere */}
                <div className="space-y-1 md:col-span-2">
                  <div className="flex items-center gap-2 text-xs text-slate-400">
                    <Cloud className="w-3 h-3" /> Atmosphere
                  </div>
                  <input 
                    type="text" 
                    value={scene.atmosphere}
                    onChange={(e) => updateScene(scene.id, 'atmosphere', e.target.value)}
                    disabled={disabled}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-sm text-slate-200 focus:border-purple-500 outline-none"
                    placeholder="e.g. Tense, mysterious, foggy"
                  />
                </div>

                {/* Characters */}
                <div className="space-y-1 md:col-span-2">
                  <div className="flex items-center gap-2 text-xs text-slate-400">
                    <Smile className="w-3 h-3" /> Characters
                  </div>
                  <input 
                    type="text" 
                    value={scene.characters}
                    onChange={(e) => updateScene(scene.id, 'characters', e.target.value)}
                    disabled={disabled}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-sm text-slate-200 focus:border-purple-500 outline-none"
                    placeholder="e.g. Detective Miller (weary), Robot X-9"
                  />
                </div>

                {/* Action */}
                <div className="space-y-1 md:col-span-2">
                  <div className="flex items-center gap-2 text-xs text-slate-400">
                    <Activity className="w-3 h-3" /> Action
                  </div>
                  <textarea 
                    value={scene.action}
                    onChange={(e) => updateScene(scene.id, 'action', e.target.value)}
                    disabled={disabled}
                    rows={2}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-sm text-slate-200 focus:border-purple-500 outline-none resize-none"
                    placeholder="e.g. Miller walks slowly towards the glowing object, hesitant to touch it."
                  />
                </div>

                {/* Dialogue */}
                <div className="space-y-1 md:col-span-2">
                  <div className="flex items-center gap-2 text-xs text-slate-400">
                    <MessageSquare className="w-3 h-3" /> Key Dialogue
                  </div>
                  <input 
                    type="text" 
                    value={scene.dialogue}
                    onChange={(e) => updateScene(scene.id, 'dialogue', e.target.value)}
                    disabled={disabled}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-sm text-slate-200 focus:border-purple-500 outline-none"
                    placeholder='e.g. "Is anyone there?"'
                  />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ScriptEditor;