import React, { useState } from 'react';
import { VisualStyle, EditingStyle, StyleOption } from '../types';
import { Film, Zap, Palette, Box, Camera, Aperture, Scissors, Video, Eye, Music, Upload, X, Image as ImageIcon } from 'lucide-react';

interface StyleSelectorProps {
  selectedVisualStyle: VisualStyle;
  selectedEditingStyle: EditingStyle;
  onSelectVisual: (style: VisualStyle) => void;
  onSelectEditing: (style: EditingStyle) => void;
  referenceImage: File | null;
  onImageUpload: (file: File | null) => void;
  disabled?: boolean;
}

const visualStyles: StyleOption[] = [
  { id: 'cinematic', name: 'Cinematic', value: VisualStyle.CINEMATIC, previewColor: 'from-blue-600 to-cyan-500', icon: 'film' },
  { id: 'cyberpunk', name: 'Cyberpunk', value: VisualStyle.CYBERPUNK, previewColor: 'from-purple-600 to-pink-500', icon: 'zap' },
  { id: 'anime', name: 'Anime', value: VisualStyle.ANIME, previewColor: 'from-orange-400 to-red-500', icon: 'palette' },
  { id: 'clay', name: 'Claymation', value: VisualStyle.CLAYMATION, previewColor: 'from-amber-700 to-yellow-600', icon: 'box' },
  { id: 'vintage', name: 'Vintage', value: VisualStyle.VINTAGE, previewColor: 'from-gray-700 to-gray-500', icon: 'aperture' },
  { id: 'surreal', name: 'Surreal', value: VisualStyle.SURREAL, previewColor: 'from-indigo-600 to-violet-600', icon: 'camera' },
];

const editingStyles: StyleOption[] = [
  { id: 'fast', name: 'Fast Paced', value: EditingStyle.FAST_PACED, previewColor: 'from-red-600 to-orange-500', icon: 'scissors' },
  { id: 'slow', name: 'Slow Cinematic', value: EditingStyle.SLOW_CINEMATIC, previewColor: 'from-blue-800 to-indigo-900', icon: 'video' },
  { id: 'docu', name: 'Documentary', value: EditingStyle.DOCUMENTARY, previewColor: 'from-emerald-600 to-teal-700', icon: 'eye' },
  { id: 'music', name: 'Music Video', value: EditingStyle.MUSIC_VIDEO, previewColor: 'from-fuchsia-600 to-pink-600', icon: 'music' },
];

const StyleSelector: React.FC<StyleSelectorProps> = ({ 
  selectedVisualStyle, 
  selectedEditingStyle, 
  onSelectVisual, 
  onSelectEditing,
  referenceImage,
  onImageUpload,
  disabled 
}) => {
  const [activeTab, setActiveTab] = useState<'visual' | 'editing' | 'reference'>('visual');
  const [dragOver, setDragOver] = useState(false);

  const getIcon = (iconName: string) => {
    switch(iconName) {
      case 'film': return <Film className="w-5 h-5 text-white" />;
      case 'zap': return <Zap className="w-5 h-5 text-white" />;
      case 'palette': return <Palette className="w-5 h-5 text-white" />;
      case 'box': return <Box className="w-5 h-5 text-white" />;
      case 'aperture': return <Aperture className="w-5 h-5 text-white" />;
      case 'camera': return <Camera className="w-5 h-5 text-white" />;
      case 'scissors': return <Scissors className="w-5 h-5 text-white" />;
      case 'video': return <Video className="w-5 h-5 text-white" />;
      case 'eye': return <Eye className="w-5 h-5 text-white" />;
      case 'music': return <Music className="w-5 h-5 text-white" />;
      default: return <Film className="w-5 h-5 text-white" />;
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(true);
  };

  const handleDragLeave = () => {
    setDragOver(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    if (disabled) return;
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const file = e.dataTransfer.files[0];
      if (file.type.startsWith('image/')) {
        onImageUpload(file);
      }
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      onImageUpload(e.target.files[0]);
    }
  };

  return (
    <div className="space-y-4">
      {/* Tabs */}
      <div className="flex p-1 bg-slate-900 rounded-lg border border-slate-800">
        <button
          onClick={() => setActiveTab('visual')}
          className={`flex-1 py-2 text-sm font-medium rounded-md transition-all ${activeTab === 'visual' ? 'bg-slate-800 text-white shadow-sm' : 'text-slate-400 hover:text-slate-200'}`}
        >
          Visual Style
        </button>
        <button
          onClick={() => setActiveTab('editing')}
          className={`flex-1 py-2 text-sm font-medium rounded-md transition-all ${activeTab === 'editing' ? 'bg-slate-800 text-white shadow-sm' : 'text-slate-400 hover:text-slate-200'}`}
        >
          Editing Style
        </button>
        <button
          onClick={() => setActiveTab('reference')}
          className={`flex-1 py-2 text-sm font-medium rounded-md transition-all ${activeTab === 'reference' ? 'bg-slate-800 text-white shadow-sm' : 'text-slate-400 hover:text-slate-200'}`}
        >
          Reference
        </button>
      </div>

      {/* Visual Styles Grid */}
      {activeTab === 'visual' && (
        <div className="grid grid-cols-2 gap-3">
          {visualStyles.map((style) => (
            <button
              key={style.id}
              disabled={disabled}
              onClick={() => onSelectVisual(style.value as VisualStyle)}
              className={`
                relative overflow-hidden rounded-xl p-3 h-20 text-left transition-all duration-300 border
                ${selectedVisualStyle === style.value 
                  ? 'border-purple-500 ring-2 ring-purple-500/50 scale-[1.02]' 
                  : 'border-slate-800 hover:border-slate-600 hover:bg-slate-800/50'
                }
                bg-slate-900 group
              `}
            >
              <div className={`absolute inset-0 opacity-20 bg-gradient-to-br ${style.previewColor} 
                ${selectedVisualStyle === style.value ? 'opacity-40' : 'group-hover:opacity-30'}`} 
              />
              <div className="relative z-10 flex flex-col justify-between h-full">
                <div className="bg-black/30 w-fit p-1 rounded-md backdrop-blur-sm">
                  {getIcon(style.icon)}
                </div>
                <span className="font-semibold text-xs text-slate-100 tracking-wide">
                  {style.name}
                </span>
              </div>
            </button>
          ))}
        </div>
      )}

      {/* Editing Styles Grid */}
      {activeTab === 'editing' && (
        <div className="grid grid-cols-2 gap-3">
          {editingStyles.map((style) => (
            <button
              key={style.id}
              disabled={disabled}
              onClick={() => onSelectEditing(style.value as EditingStyle)}
              className={`
                relative overflow-hidden rounded-xl p-3 h-20 text-left transition-all duration-300 border
                ${selectedEditingStyle === style.value 
                  ? 'border-pink-500 ring-2 ring-pink-500/50 scale-[1.02]' 
                  : 'border-slate-800 hover:border-slate-600 hover:bg-slate-800/50'
                }
                bg-slate-900 group
              `}
            >
              <div className={`absolute inset-0 opacity-20 bg-gradient-to-br ${style.previewColor} 
                ${selectedEditingStyle === style.value ? 'opacity-40' : 'group-hover:opacity-30'}`} 
              />
              <div className="relative z-10 flex flex-col justify-between h-full">
                <div className="bg-black/30 w-fit p-1 rounded-md backdrop-blur-sm">
                  {getIcon(style.icon)}
                </div>
                <span className="font-semibold text-xs text-slate-100 tracking-wide">
                  {style.name}
                </span>
              </div>
            </button>
          ))}
        </div>
      )}

      {/* Reference Image Upload */}
      {activeTab === 'reference' && (
        <div className="space-y-4">
          <div 
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
            className={`
              border-2 border-dashed rounded-xl p-6 flex flex-col items-center justify-center text-center transition-all h-40
              ${dragOver 
                ? 'border-purple-500 bg-purple-500/10' 
                : referenceImage 
                  ? 'border-green-500/50 bg-green-500/5' 
                  : 'border-slate-700 bg-slate-900/30 hover:bg-slate-900/50'
              }
              ${disabled ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer'}
            `}
          >
            {referenceImage ? (
              <div className="relative w-full h-full flex items-center justify-center">
                 <img 
                   src={URL.createObjectURL(referenceImage)} 
                   alt="Reference" 
                   className="h-full w-auto object-contain rounded-lg shadow-lg"
                 />
                 <button 
                   onClick={(e) => { e.stopPropagation(); onImageUpload(null); }}
                   className="absolute -top-2 -right-2 bg-red-500 text-white p-1 rounded-full shadow-lg hover:bg-red-600"
                 >
                   <X className="w-4 h-4" />
                 </button>
              </div>
            ) : (
              <>
                <div className="w-12 h-12 rounded-full bg-slate-800 flex items-center justify-center mb-3 text-purple-400">
                  <Upload className="w-6 h-6" />
                </div>
                <p className="text-sm text-slate-300 font-medium">Click or Drag & Drop</p>
                <p className="text-xs text-slate-500 mt-1">Upload an image as a style reference</p>
                <input 
                  type="file" 
                  accept="image/*"
                  onChange={handleFileSelect}
                  disabled={disabled}
                  className="absolute inset-0 opacity-0 cursor-pointer"
                />
              </>
            )}
          </div>
          <p className="text-xs text-slate-500 text-center px-4">
            The AI will use this image as the starting frame or style reference for your video generation.
          </p>
        </div>
      )}
    </div>
  );
};

export default StyleSelector;