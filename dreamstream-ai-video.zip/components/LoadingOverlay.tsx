import React from 'react';
import { Loader2, Sparkles } from 'lucide-react';

interface LoadingOverlayProps {
  isVisible: boolean;
}

const LoadingOverlay: React.FC<LoadingOverlayProps> = ({ isVisible }) => {
  if (!isVisible) return null;

  return (
    <div className="absolute inset-0 z-50 flex flex-col items-center justify-center bg-slate-950/90 backdrop-blur-sm rounded-xl border border-slate-800">
      <div className="relative">
        <div className="absolute inset-0 bg-purple-500 blur-xl opacity-20 animate-pulse"></div>
        <Loader2 className="w-16 h-16 text-purple-500 animate-spin relative z-10" />
      </div>
      <h3 className="mt-6 text-xl font-bold text-white flex items-center gap-2">
        <Sparkles className="w-5 h-5 text-yellow-400" />
        Dreaming up your video...
      </h3>
      <p className="mt-2 text-slate-400 text-sm max-w-xs text-center animate-pulse">
        This takes a moment. The AI is directing, filming, and editing your scene.
      </p>
    </div>
  );
};

export default LoadingOverlay;