import React, { useState, useEffect, useRef } from 'react';
import { Play, Download, AlertCircle, Wand2, Video, KeyRound, Clock, Activity, Clapperboard } from 'lucide-react';
import StyleSelector from './components/StyleSelector';
import ScriptEditor from './components/ScriptEditor';
import LoadingOverlay from './components/LoadingOverlay';
import { VisualStyle, EditingStyle, VideoDuration, Complexity, ScriptData } from './types';
import { generateVideoContent, checkApiKey, promptForKeySelection } from './services/geminiService';

const App: React.FC = () => {
  const [hasKey, setHasKey] = useState<boolean>(false);
  
  // State for structured inputs
  const [scriptData, setScriptData] = useState<ScriptData>({
    plot: '',
    scenes: [{
      id: '1',
      location: '',
      time: '',
      atmosphere: '',
      characters: '',
      action: '',
      dialogue: ''
    }]
  });

  const [visualStyle, setVisualStyle] = useState<VisualStyle>(VisualStyle.CINEMATIC);
  const [editingStyle, setEditingStyle] = useState<EditingStyle>(EditingStyle.SLOW_CINEMATIC);
  const [duration, setDuration] = useState<VideoDuration>(VideoDuration.ONE_MIN);
  const [complexity, setComplexity] = useState<Complexity>(Complexity.SIMPLE);
  const [referenceImage, setReferenceImage] = useState<File | null>(null);

  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    const initKey = async () => {
      const authorized = await checkApiKey();
      setHasKey(authorized);
    };
    initKey();
  }, []);

  const handleConnectKey = async () => {
    try {
      await promptForKeySelection();
      setHasKey(true);
      setError(null);
    } catch (e) {
      console.error(e);
      setError("Failed to connect API key.");
    }
  };

  const handleGenerate = async () => {
    if (!scriptData.plot.trim()) {
      setError("Please enter a main plot for the video.");
      return;
    }
    if (!hasKey) {
      handleConnectKey();
      return;
    }

    setIsGenerating(true);
    setError(null);
    setVideoUrl(null);

    try {
      const url = await generateVideoContent(scriptData, {
        visualStyle,
        editingStyle,
        duration,
        complexity,
        referenceImage
      });
      setVideoUrl(url);
    } catch (err: any) {
      setError(err.message || "Something went wrong during generation.");
    } finally {
      setIsGenerating(false);
    }
  };

  const handleDownload = async () => {
    if (videoUrl) {
      try {
        const response = await fetch(videoUrl);
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `dreamstream-video-${Date.now()}.mp4`;
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        document.body.removeChild(a);
      } catch (e) {
        setError("Download failed. The link might have expired.");
      }
    }
  };

  return (
    <div className="min-h-screen flex flex-col items-center bg-slate-950 text-slate-100">
      
      {/* Header */}
      <header className="w-full sticky top-0 z-30 bg-slate-950/80 backdrop-blur-md border-b border-slate-800">
        <div className="max-w-7xl mx-auto px-4 md:px-8 h-16 flex justify-between items-center">
          <div className="flex items-center gap-3">
            <div className="bg-gradient-to-r from-purple-600 to-pink-600 p-2 rounded-lg shadow-lg shadow-purple-900/20">
              <Clapperboard className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold tracking-tight text-white leading-none">DreamStream</h1>
              <p className="text-[10px] text-slate-400 uppercase tracking-widest font-semibold">Director's Cut</p>
            </div>
          </div>
          
          <button
            onClick={handleConnectKey}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-medium transition-all ${
              hasKey 
                ? 'bg-green-950/30 text-green-400 border border-green-900/50' 
                : 'bg-slate-800 text-slate-300 hover:bg-slate-700 border border-slate-700'
            }`}
          >
            <KeyRound className="w-3 h-3" />
            {hasKey ? 'API Connected' : 'Connect Key'}
          </button>
        </div>
      </header>

      <main className="w-full max-w-7xl mx-auto px-4 md:px-8 py-8 grid lg:grid-cols-12 gap-8">
        
        {/* LEFT COLUMN: Script & Content (7 Cols) */}
        <div className="lg:col-span-7 space-y-8">
          <div className="space-y-4">
             <div className="flex items-center gap-2 text-purple-400 mb-2">
               <Video className="w-5 h-5" />
               <h2 className="text-lg font-semibold text-white">Script & Narrative</h2>
             </div>
             
             <ScriptEditor 
               data={scriptData} 
               onChange={setScriptData}
               disabled={isGenerating} 
             />
          </div>
        </div>

        {/* RIGHT COLUMN: Settings & Preview (5 Cols) */}
        <div className="lg:col-span-5 flex flex-col gap-6 sticky top-24 h-fit">
          
          {/* Preview Window */}
          <div className="bg-slate-900 rounded-2xl border border-slate-800 overflow-hidden shadow-2xl aspect-video relative group">
              <LoadingOverlay isVisible={isGenerating} />
              
              {videoUrl ? (
                <div className="relative w-full h-full bg-black">
                  <video 
                    ref={videoRef}
                    className="w-full h-full object-contain"
                    controls
                    autoPlay
                    loop
                    src={videoUrl}
                  />
                  <div className="absolute top-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button 
                      onClick={handleDownload}
                      className="bg-black/50 hover:bg-black/70 backdrop-blur-md text-white p-2 rounded-lg border border-white/10"
                      title="Download Video"
                    >
                      <Download className="w-5 h-5" />
                    </button>
                  </div>
                </div>
              ) : (
                <div className="w-full h-full flex flex-col items-center justify-center text-slate-500 p-8 text-center bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-slate-800/50 to-slate-900">
                  <div className="w-16 h-16 rounded-full bg-slate-800 flex items-center justify-center mb-4 ring-1 ring-slate-700">
                    <Play className="w-6 h-6 ml-1 opacity-50" />
                  </div>
                  <h3 className="text-sm font-medium text-slate-300">Preview Screen</h3>
                  <p className="text-xs mt-1 max-w-[200px] text-slate-500">
                    Your generated scene will appear here.
                  </p>
                </div>
              )}
          </div>

          {/* Configuration Controls */}
          <div className="bg-slate-900/50 border border-slate-800 rounded-2xl p-6 space-y-6">
            
            {/* Duration & Complexity Grid */}
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider flex items-center gap-1">
                  <Clock className="w-3 h-3" /> Duration
                </label>
                <select 
                  value={duration}
                  onChange={(e) => setDuration(e.target.value as VideoDuration)}
                  disabled={isGenerating}
                  className="w-full bg-slate-950 border border-slate-700 text-sm rounded-lg p-2.5 text-slate-200 focus:border-purple-500 outline-none"
                >
                  {Object.values(VideoDuration).map(d => (
                    <option key={d} value={d}>{d}</option>
                  ))}
                </select>
              </div>

              <div className="space-y-2">
                <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider flex items-center gap-1">
                  <Activity className="w-3 h-3" /> Complexity
                </label>
                <select 
                  value={complexity}
                  onChange={(e) => setComplexity(e.target.value as Complexity)}
                  disabled={isGenerating}
                  className="w-full bg-slate-950 border border-slate-700 text-sm rounded-lg p-2.5 text-slate-200 focus:border-purple-500 outline-none"
                >
                  {Object.values(Complexity).map(c => (
                    <option key={c} value={c}>{c}</option>
                  ))}
                </select>
              </div>
            </div>

            {/* Styles & Reference */}
            <div className="space-y-2">
              <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Production Style</label>
              <StyleSelector 
                selectedVisualStyle={visualStyle} 
                selectedEditingStyle={editingStyle}
                onSelectVisual={setVisualStyle}
                onSelectEditing={setEditingStyle}
                referenceImage={referenceImage}
                onImageUpload={setReferenceImage}
                disabled={isGenerating}
              />
            </div>

            {/* Generate Button */}
            <button
              onClick={handleGenerate}
              disabled={isGenerating || !scriptData.plot.trim()}
              className={`
                w-full py-4 rounded-xl font-bold text-lg flex items-center justify-center gap-2 transition-all transform active:scale-[0.98] shadow-lg
                ${isGenerating 
                  ? 'bg-slate-800 text-slate-500 cursor-not-allowed' 
                  : 'bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 text-white shadow-purple-900/20'
                }
              `}
            >
              {isGenerating ? (
                'Directing Scene...'
              ) : (
                <>
                  <Wand2 className="w-5 h-5" />
                  Generate Video
                </>
              )}
            </button>

            {/* Status Messages */}
            {!hasKey && (
              <div className="bg-amber-900/20 border border-amber-900/50 p-3 rounded-lg text-amber-200 text-xs flex gap-2">
                <AlertCircle className="w-4 h-4 flex-shrink-0" />
                <p>Paid API key required for Veo.</p>
              </div>
            )}
            
            {error && (
              <div className="bg-red-900/20 border border-red-900/50 p-3 rounded-lg text-red-200 text-xs flex gap-2">
                <AlertCircle className="w-4 h-4 flex-shrink-0" />
                <p>{error}</p>
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
};

export default App;